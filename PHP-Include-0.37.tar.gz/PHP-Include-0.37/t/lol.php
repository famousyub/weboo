<?php

$list = Array( 'a',
                // some comment
                array('baa', 'bee', 'bii', 'boo', 'buu'),
                # Some other comment
                array(1, 2, 3, 4, 5),
                69,
    );

$x = 42;

?>
