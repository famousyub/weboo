<?php

$hash1 = Array( 'a' => 1,
                // Some comment
                'b' => array('baa', 'bee', 'bii', 'boo', 'buu'),
                # Some other comment
                'c' => array(1, 2, 3, 4, 5),
    );

$x = 42;

?>
