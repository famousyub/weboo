<?php

$list = Array( 'a',
               // some comment
               array('baa' => 'bee', 'bii' => 'boo'),
               # Some other comment
               array(1 => 23, 4 => 5),
               69,
    );

$x = 42;

?>
