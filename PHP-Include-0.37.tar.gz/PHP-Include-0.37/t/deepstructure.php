<?php

$structure =
      array( 'names' => array( 'a' => array( 'alberto', 'antonio'),
                               'b' => array( 'burro', 'brain')),
             'ages' => array( 10, 20, 30, 40),
          );

$x = 42;

?>
