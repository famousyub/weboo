<?php

$hash1 = Array( 'a' => 1,
                'b' => array('baa' => 'bee', 
                             'bii' => 'boo'),
                'c' => array(1 => 2, 
                             3 => 4),
    );

$x = 42;

?>
