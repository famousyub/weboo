<?php
defined('PHPFOX') or exit('NO DICE!');
?>

<div id="js_review_entry_block">
    {template file='advancedmarketplace.block.review-entry'}
</div>
<div class="p-advmarketplace-review-listing-container">
    <div class="item-review-listing-wrapper js_reviewer_listing">
        {module name='advancedmarketplace.reviewer-listing'}
    </div>
</div>
