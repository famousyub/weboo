<div class="anoption">
	<label>{phrase var='advancedmarketplace.option'}: <input type="text" name="customfield[{$iCusfieldId}][options][{$sKeyVarOption}]" value="{$sTextOption}" /></label>
	<input type="hidden" value="{$iCusfieldId}" class="ghs_cid" />
	<a href="#" title="{phrase var='advancedmarketplace.move_up'}" class="btn1 up">&nbsp;</a>
	<a href="#" title="{phrase var='advancedmarketplace.move_down'}" class="btn1 down">&nbsp;</a>
	<a href="#" title="{phrase var='advancedmarketplace.delete'}" class="btn1 delete yn_jh_cusfield_delete" ref="{$sKeyVarOption}">&nbsp;</a>
</div>