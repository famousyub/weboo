<?php
defined('PHPFOX') or exit('NO DICE!');
?>

<link rel="stylesheet" type="text/css" href="{$appPath}assets/embed.css" />
{template file='advancedmarketplace.block.feed'}
