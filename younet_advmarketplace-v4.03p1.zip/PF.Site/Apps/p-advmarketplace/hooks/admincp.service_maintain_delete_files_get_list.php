<?php

$aPluginFiles[] = 'PF.Base/module/advancedmarketplace/';
