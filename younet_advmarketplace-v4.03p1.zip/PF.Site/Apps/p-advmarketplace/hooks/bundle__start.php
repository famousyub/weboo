<?php
;
$aBundleScripts[] = [
    'autoload.js' => 'app_p-advmarketplace',
    'jscript/ynmarketplace.js' => 'app_p-advmarketplace',
];

