# SocialNetwork
Social network using MongoDB, Neo4J, ASP.NET Core Web Api.

Client : https://github.com/voroniak/social-network-client
