﻿namespace SocialNetwork.Api.Data.Repository.Settings
{
    public class MongoDbSettings: IMongoDbSettings
    {
        public string DatabaseName { get; set; }
        public string ConnectionString { get; set; }

    }
}
