﻿namespace SocialNetwork.Api.Data.DTOs
{
    public class PostEditDto
    {
        public string Id { get; set; }

        public string Text { get; set; }

    }
}
