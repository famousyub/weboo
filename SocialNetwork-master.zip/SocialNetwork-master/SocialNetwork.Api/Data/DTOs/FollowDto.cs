﻿namespace SocialNetwork.Api.Data.DTOs
{
    public class FollowDto
    {
        public string FollowerUserId { get; set; }
        public string FollowingUserId { get; set; }
    }
}
