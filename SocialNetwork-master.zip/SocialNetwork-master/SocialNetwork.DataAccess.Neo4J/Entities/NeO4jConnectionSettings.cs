﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SocialNetwork.DataAccess.Neo4J.Entities
{
    class NeO4jConnectionSettings
    {
        public string Server { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
