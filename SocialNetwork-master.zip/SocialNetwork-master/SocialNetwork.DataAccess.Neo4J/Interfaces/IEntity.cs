﻿
namespace SocialNetwork.DataAccess.Neo4J.Interfaces
{
    public class IEntity
    {
    }
}
