# Awesome Public Datasets Core

[![Build Status](https://travis-ci.org/awesomedata/apd-core.svg?branch=master)](https://travis-ci.org/awesomedata/apd-core)

Next iteration of APD project.

## How to contribute

Please refer to the instructions of [CONTRIBUTING](https://github.com/awesomedata/apd-core/blob/master/CONTRIBUTING.md) or latest [Wiki](https://github.com/awesomedata/apd-core/wiki).

## Contact

Xiaming Chen <chenxm35@gmail.com>
