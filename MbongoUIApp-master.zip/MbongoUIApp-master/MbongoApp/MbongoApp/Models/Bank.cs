﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MbongoApp.Models
{
   public class Bank
    {

        public string bankLogo { get; set; }
        public string bankName { get; set; }
    }
}
